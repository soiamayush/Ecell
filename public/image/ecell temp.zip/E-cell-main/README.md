# ecell
Website for Entrepreneurship Cell, jec jabalpur
